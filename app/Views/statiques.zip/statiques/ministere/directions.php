			
			<!-- SAB BANNER START-->
			<!-- <div class="sab_banner overlay">
				<div class="container">
					<div class="sab_banner_text">
						<h2>Les directions du ministere</h2>
						
					</div>
				</div>
			</div> -->
			<!-- SAB BANNER END-->
			<!--CITY ABOUT WRAP START-->
			<div class="city_department_wrap goverment">
				<div class="container">
					<!--SECTION HEADING START-->
					<div class="section_heading margin-bottom">
						<span>MPEM</span>
						<h2>Administration generale</h2>
					</div>
					<!--SECTION HEADING END-->
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/services.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/services.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<div class="section_heading margin-bottom">
						<span>MPEM</span>
						<h2>Les directions de l'energie</h2>
					</div>
					<!--SECTION HEADING END-->
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/energie.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/energie.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<!--SECTION HEADING START-->
					<div class="section_heading margin-bottom">
						<span>MPEM</span>
						<h2>Les directions du petrole</h2>
					</div>
					<!--SECTION HEADING END-->
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/petrole.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/petrole.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
					</div>
					<!--SECTION HEADING START-->
					<div class="section_heading margin-bottom">
						<span>MPEM</span>
						<h2>Les directions des mines</h2>
					</div>
					<!--SECTION HEADING END-->
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
						<div class="col-md-4 col-sm-6">
							<div class="width_control">
								<div class="city_department_fig">
									<figure class="box">
										<div class="box-layer layer-1"></div>
										<div class="box-layer layer-2"></div>
										<div class="box-layer layer-3"></div>
										<img src="assets/extra-images/mines.png" alt="">
										<a class="paly_btn" data-rel="prettyPhoto" href="assets/extra-images/mines.png"><i class="fa fa-plus"></i></a>
									</figure>
									<div class="city_department_text">
										<h5>DAGE</h5>
										<p>Direction de l'Administration Generale et de l'Equipement </p>
									</div>
								</div>
							</div>
						</div>	
					</div>
					</div>
				</div>
			</div>	
			<!--CITY ABOUT WRAP START-->
