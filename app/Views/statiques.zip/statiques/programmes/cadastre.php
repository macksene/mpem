<body class="demo-5">
	<!--wraper start--> 
	  <div class="wraper">	

	  <div class="sab_banner">
				<div class="container">
					<div class="sab_banner_text">
						<ul class="breadcrumb">
						    <li class="breadcrumb-item"><a href="#">Home</a></li>
    						<li class="breadcrumb-item active" aria-current="page">Event</li>
						</ul>
						<h2 class="custom_size01">ORGANISMES SOUS TUTELLE DU MINISTERE</h2>
					</div>
				</div>
			</div>
			<!--sab banner end-->
			<!--event wrap start-->
			<div class="event_detail bg_clr">
				<div class="container">
					<!--blog list row start-->
					<div class="blog_list_row">
						<div class="event_detail_row">
							<figure>
								<img src="assets/images/counter-bg.png" alt="">
							</figure>
							<div class="event_detail_list">
								<div class="event_detail_text">
									<h3>ORGANISMES SOUS TUTELLE DU MINISTERE</h3>
									<p>

Le Secrétaire général, placé sous l’autorité hiérarchique du Ministre, l’assiste dans l’exécution de la politique gouvernementale et dans l’administration du département.
A cet effet, il est chargé, notamment :

    de la coordination des activités des différents services du ministère dont il s’assure du bon fonctionnement ;
    de la préparation et du contrôle de l’exécution des décisions ministérielles ;
    de l’information du Ministre sur l’état de fonctionnement de son département et particulièrement sur la gestion des crédits du ministère ;
    des relations et de la coordination avec les autres départements ministériels en vue de l’exécution des décisions interministérielles ;
</p>
									<a class="theam_btn btn2 text_white bg_color" href="#">Join Now</a>
								</div>
								<div class="event_detail_info">
									<div class="event_deta_colume">
										<div class="event_date">
										<figure>
								<img src="assets/images/leministre.png" alt="">
							</figure>
										</div>
										<div class="event_deta_caption">
											<h4>Chef de cabinet</h4>
										</div>
									</div>
									<ul class="event_list">
										<li><a href="#"><i class="fa fa-calendar"></i> <span>Timing:</span> 06:00 Pm - 09:30 Pm</a></li>
										<li><a href="#"><i class="fa fa-map-marker"></i> <span>Locations:</span>NY United States</a></li>
										<li><a href="#"><i class="fa fa-calendar"></i> <span>Cost:</span>Free Event</a></li>
										<li><a href="#"><i class="fa fa-map-marker"></i> <span>Phone:</span> 542-389-5609</a></li>
										<li><a href="#"><i class="fa fa-calendar"></i> <span>Email:</span> cookies@kf.com</a></li>
										<li><a href="#"><i class="fa fa-map-marker"></i> <span>Website:</span>www.event.com</a></li>
										<li><a href="#"><i class="fa fa-map-marker"></i> <span>Category:</span> Help, Meetup, Fundrasisng</a></li>
									</ul>
								</div>
							</div>
						</div>

						<!--event speaker start-->
						<div class="event_speaker">
							<div class="section_heading text-center margin30">
								<span class="theme_color2">Le cabinet du ministre</span>
								<h2 class="theme_color">MEMBRES DU CABINET</h2>
								<div class="heading_star block-bdr brd_color"><span class="theme_color2"><i class="fa fa-star"></i></span></div>
							</div>
							<div class="event-team-slider">
								<div>
									<div class="event_speaker_fig">
										<figure class="overlay">
											<img src="assets/images/leministre.png">
											<ul class="social_share">
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-facebook"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-twitter"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-linkedin"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-youtube"></i></span></a></li>
											</ul>
										</figure>
										<h5>Alimatou Sow</h5>
									</div>
								</div>
								<div>
									<div class="event_speaker_fig">
										<figure class="overlay">
											<img src="assets/images/leministre.png">
											<ul class="social_share">
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-facebook"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-twitter"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-linkedin"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-youtube"></i></span></a></li>
											</ul>
										</figure>
										<h5>Fatimatou Faye</h5>
									</div>
								</div>
								<div>
									<div class="event_speaker_fig">
										<figure class="overlay">
											<img src="assets/images/leministre.png">
											<ul class="social_share">
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-facebook"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-twitter"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-linkedin"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-youtube"></i></span></a></li>
											</ul>
										</figure>
										<h5>Aliou Seck</h5>
									</div>
								</div>
								<div>
									<div class="event_speaker_fig">
										<figure class="overlay">
											<img src="assets/images/leministre.png">
											<ul class="social_share">
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-facebook"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-twitter"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-linkedin"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-youtube"></i></span></a></li>
											</ul>
										</figure>
										<h5>Mariama Tall</h5>
									</div>
								</div>
								<div>
									<div class="event_speaker_fig">
										<figure class="overlay">
											<img src="assets/images/leministre.png">
											<ul class="social_share">
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-facebook"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-twitter"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon.png"><span><i class="fa fa-linkedin"></i></span></a></li>
												<li><a href="#"><img src="assets/images/shape-icon1.png"><span><i class="fa fa-youtube"></i></span></a></li>
											</ul>
										</figure>
										<h5>Adam Ly</h5>
									</div>
								</div>
							</div>
						</div>
						<!--event speaker end-->

				

						<!--event tabs wrap start-->
						<div class="event_tabs_wrap">
							<ul id="tabs" class="event_tabs_link">
								<li  role="presentation" class="active"><a href="#Facilities"  role="tab" data-toggle="tab">Missions</a></li>
								<li  role="presentation"><a href="#Location"  role="tab" data-toggle="tab">Map Location</a></li>
								<li  role="presentation"><a href="#Contact"  role="tab" data-toggle="tab">Contact Us</a></li>
							</ul>
							<div class="row tab-content">
							<div role="tabpanel" class="tab-pane fade in active" id="Facilities">
								<div class="event_tabs_row">
									<figure>
										<img src="assets/extra-images/event-tabs.jpg" alt="">
									</figure>
									<div class="event_tabs_text">
										<h4>Event Facilities</h4>
										<p>663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lor663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut .</p>
										<ul class="event_tabs_list">
											<li><a href="#">Import financial information from popular sources</a></li>
											<li><a href="#">Support provided 24/7 by our own experts</a></li>
											<li><a href="#">One decision that will have the largest impact</a></li>
											<li><a href="#">Afforadable prices and payment options available</a></li>
										</ul>
									</div>	
								</div>
							</div>
							<div role="tabpanel" class="tab-pane fade in" id="Location">
								<div class="event_tabs_row">
									<figure>
										<img src="assets/extra-images/event-tabs.jpg" alt="">
									</figure>
									<div class="event_tabs_text">
										<h4>Event Facilities</h4>
										<p>663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lor663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut .</p>
										<ul class="event_tabs_list">
											<li><a href="#">Import financial information from popular sources</a></li>
											<li><a href="#">Support provided 24/7 by our own experts</a></li>
											<li><a href="#">One decision that will have the largest impact</a></li>
											<li><a href="#">Afforadable prices and payment options available</a></li>
										</ul>
									</div>	
								</div>
							</div>
							<div role="tabpanel" class="tab-pane fade in" id="Contact">
								<div class="event_tabs_row">
									<figure>
										<img src="assets/extra-images/event-tabs.jpg" alt="">
									</figure>
									<div class="event_tabs_text">
										<h4>Event Facilities</h4>
										<p>663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lor663 million people drink dirty water. Learn how access to clean water can improve health, boost local econom mies. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut .</p>
										<ul class="event_tabs_list">
											<li><a href="#">Import financial information from popular sources</a></li>
											<li><a href="#">Support provided 24/7 by our own experts</a></li>
											<li><a href="#">One decision that will have the largest impact</a></li>
											<li><a href="#">Afforadable prices and payment options available</a></li>
										</ul>
									</div>	
								</div>
							</div>
						</div>
						<!--event tabs wrap end-->
					</div>
					<div class="event2">
						<div class="section_heading text-center margin30">
							<span class="theme_color2">Cabinet</span>
							<h2 class="theme_color">publications</h2>
							<div class="heading_star block-bdr brd_color"><span class="theme_color2"><i class="fa fa-star"></i></span></div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="event_colume">
									<figure>
										<img src="assets/extra-images/event-grid.jpg" alt="">
									</figure>
									<div class="event_colume_text">
										<div class="event_date">
											<h4>21</h4>
											<span>April</span>
										</div>
										<h4>Independence Day: July 4</h4>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquetnean</p>
										<ul class="event_list">
											<li><a href="#"><i class="fa fa-calendar"></i> <span>Timing:</span> 06:00 Pm - 09:30 Pm</a></li>
											<li><a href="#"><i class="fa fa-map-marker"></i> <span>Locations:</span> New York, NY United States</a></li>
										</ul>
										<div class="event_find_more">
											<a class="theam_btn btn2 text_white bg_color" href="#">Find Out More</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="event_colume">
									<figure>
										<img src="assets/extra-images/event-grid1.jpg" alt="">
									</figure>
									<div class="event_colume_text">
										<div class="event_date">
											<h4>21</h4>
											<span>April</span>
										</div>
										<h4>Independence Day: July 4</h4>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquetnean</p>
										<ul class="event_list">
											<li><a href="#"><i class="fa fa-calendar"></i> <span>Timing:</span> 06:00 Pm - 09:30 Pm</a></li>
											<li><a href="#"><i class="fa fa-map-marker"></i> <span>Locations:</span> New York, NY United States</a></li>
										</ul>
										<div class="event_find_more">
											<a class="theam_btn btn2 text_white bg_color" href="#">Find Out More</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="event_colume">
									<figure>
										<img src="assets/extra-images/event-grid2.jpg" alt="">
									</figure>
									<div class="event_colume_text">
										<div class="event_date">
											<h4>21</h4>
											<span>April</span>
										</div>
										<h4>Independence Day: July 4</h4>
										<p>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquetnean</p>
										<ul class="event_list">
											<li><a href="#"><i class="fa fa-calendar"></i> <span>Timing:</span> 06:00 Pm - 09:30 Pm</a></li>
											<li><a href="#"><i class="fa fa-map-marker"></i> <span>Locations:</span> New York, NY United States</a></li>
										</ul>
										<div class="event_find_more">
											<a class="theam_btn btn2 text_white bg_color" href="#">Find Out More</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--event wrap end-->
		