
			
			<!-- CITY EVENT2 WRAP START-->
			<div class="city_event2_wrap">
				<div class="container">
					<!--SECTION HEADING START-->
					
					<div class="section_heading margin-bottom">
						<span>MPEM</span>
						<h2>Les titres miniers</h2>
					</div>
					<!--SECTION HEADING END-->
					<div class="row">
						<div class="col-md-3">
							<div class="sidebar_widget">
							
								
								<!-- EVENT SIDEBAR START-->
								<div class="event_sidebar">
									<h4 class="sidebar_heading">Types de titres</h4>
									<div class="categories_list">
										<ul>
											<li><a href="#">Licences de distribution</a></li>
											<li><a href="#">Titres miniers</a></li>
											<li><a href="#">Permis de recherche</a></li>
											<li><a href="#">Autorisations d'exploitation</a></li>
										</ul>
									</div>
								</div>
								<!-- EVENT SIDEBAR END-->

								


							</div>
						</div>
						<div class="col-md-9">
							
							
							<div class="city_event2_list2">
								<ul>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Mines et geologie</span>
												<h4><a href="#">Autorisation de prospection miniere</a></h4>
												<ul class="city_meta_list">

													<li><a href="#"></a></li>
												</ul>
												<p>La demande d'autorisation de prospection est adressée en trois (3) exemplaires originaux au
												Directeur des Mines et de la Géologie..</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Voir</a>
													
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list1.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Conference</span>
												<h4><a href="#">Municipal Community  Conference</a></h4>
												<ul class="city_meta_list">
													<li><a href="#"><i class="fa fa-microphone"></i>John Doe</a></li>
													<li><a href="#"><i class="fa fa-clock-o"></i>10.00AM - 11.30AM</a></li>
													<li><a href="#"><i class="fa fa-map-marker"></i>Pantero Hotel, USA</a></li>
												</ul>
												<p>This iThis is Photoshop's version  of Lorem Ipsum. Mauris in erat justo. Etiam pharetra,  velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Join Event</a>
													<div class="city_blog_icon_list">
														<ul class="social_icon">
															<li><a href="#"><i class="fa fa-facebook"></i></a></li>
															<li><a href="#"><i class="fa fa-twitter"></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
															<li><a href="#"><i class="fa fa-google"></i></a></li>
														</ul>
														<a class="share_icon" href="#"><i class="fa icon-social"></i></a>
													</div>
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list2.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Conference</span>
												<h4><a href="#">Municipal Community  Conference</a></h4>
												<ul class="city_meta_list">
													<li><a href="#"><i class="fa fa-microphone"></i>John Doe</a></li>
													<li><a href="#"><i class="fa fa-clock-o"></i>10.00AM - 11.30AM</a></li>
													<li><a href="#"><i class="fa fa-map-marker"></i>Pantero Hotel, USA</a></li>
												</ul>
												<p>This iThis is Photoshop's version  of Lorem Ipsum. Mauris in erat justo. Etiam pharetra,  velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Join Event</a>
													<div class="city_blog_icon_list">
														<ul class="social_icon">
															<li><a href="#"><i class="fa fa-facebook"></i></a></li>
															<li><a href="#"><i class="fa fa-twitter"></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
															<li><a href="#"><i class="fa fa-google"></i></a></li>
														</ul>
														<a class="share_icon" href="#"><i class="fa icon-social"></i></a>
													</div>
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list3.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Conference</span>
												<h4><a href="#">Municipal Community  Conference</a></h4>
												<ul class="city_meta_list">
													<li><a href="#"><i class="fa fa-microphone"></i>John Doe</a></li>
													<li><a href="#"><i class="fa fa-clock-o"></i>10.00AM - 11.30AM</a></li>
													<li><a href="#"><i class="fa fa-map-marker"></i>Pantero Hotel, USA</a></li>
												</ul>
												<p>This iThis is Photoshop's version  of Lorem Ipsum. Mauris in erat justo. Etiam pharetra,  velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Join Event</a>
													<div class="city_blog_icon_list">
														<ul class="social_icon">
															<li><a href="#"><i class="fa fa-facebook"></i></a></li>
															<li><a href="#"><i class="fa fa-twitter"></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
															<li><a href="#"><i class="fa fa-google"></i></a></li>
														</ul>
														<a class="share_icon" href="#"><i class="fa icon-social"></i></a>
													</div>
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Conference</span>
												<h4><a href="#">Municipal Community  Conference</a></h4>
												<ul class="city_meta_list">
													<li><a href="#"><i class="fa fa-microphone"></i>John Doe</a></li>
													<li><a href="#"><i class="fa fa-clock-o"></i>10.00AM - 11.30AM</a></li>
													<li><a href="#"><i class="fa fa-map-marker"></i>Pantero Hotel, USA</a></li>
												</ul>
												<p>This iThis is Photoshop's version  of Lorem Ipsum. Mauris in erat justo. Etiam pharetra,  velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Join Event</a>
													<div class="city_blog_icon_list">
														<ul class="social_icon">
															<li><a href="#"><i class="fa fa-facebook"></i></a></li>
															<li><a href="#"><i class="fa fa-twitter"></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
															<li><a href="#"><i class="fa fa-google"></i></a></li>
														</ul>
														<a class="share_icon" href="#"><i class="fa icon-social"></i></a>
													</div>
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="city_event2_list2_row">
											<div class="city_event2_list2_fig">
												<figure class="box">
													<div class="box-layer layer-1"></div>
													<div class="box-layer layer-2"></div>
													<div class="box-layer layer-3"></div>
													<img src="assets/extra-images/event-list1.jpg" alt="">
													<div class="event_categories_date">
														<h5>07</h5>
														<p>Sep 2018</p>
													</div>
												</figure>
											</div>
											<div class="city_blog_text event2">
												<span>Conference</span>
												<h4><a href="#">Municipal Community  Conference</a></h4>
												<ul class="city_meta_list">
													<li><a href="#"><i class="fa fa-microphone"></i>John Doe</a></li>
													<li><a href="#"><i class="fa fa-clock-o"></i>10.00AM - 11.30AM</a></li>
													<li><a href="#"><i class="fa fa-map-marker"></i>Pantero Hotel, USA</a></li>
												</ul>
												<p>This iThis is Photoshop's version  of Lorem Ipsum. Mauris in erat justo. Etiam pharetra,  velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
												<div class="city_blog_social">
													<a class="theam_btn border-color" href="#" tabindex="0">Join Event</a>
													<div class="city_blog_icon_list">
														<ul class="social_icon">
															<li><a href="#"><i class="fa fa-facebook"></i></a></li>
															<li><a href="#"><i class="fa fa-twitter"></i></a></li>
															<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
															<li><a href="#"><i class="fa fa-google"></i></a></li>
														</ul>
														<a class="share_icon" href="#"><i class="fa icon-social"></i></a>
													</div>
												</div>
											</div>
										</div>
									</li>
								</ul>
								<div class="pagination">
									<ul>
										<li><a href="#"><i class="fa fa-angle-left"></i></a></li>
										<li><a href="#">01</a></li>
										<li><a href="#">02</a></li>
										<li><a href="#">....</a></li>
										<li><a href="#">08</a></li>
										<li><a href="#"><i class="fa fa-angle-right"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- CITY EVENT2 WRAP END-->