<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>MPEM</title>
		<!-- ICONS CSS -->
        <link href="assets/css/animation.css" rel="stylesheet">
		<!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">
		<!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap-new.css" rel="stylesheet">
        <!-- Slick Slider CSS -->
        <link href="assets/css/slick-theme.css" rel="stylesheet"/>
        <!-- ICONS CSS -->
        <link href="assets/css/font-awesome.css" rel="stylesheet">
		<!-- JQUERY UI -->
		<!-- ICONS CSS -->
        <link href="assets/css/selectric.css" rel="stylesheet">
        <link href="assets/css/jquery-ui.css" rel="stylesheet">
        <!-- Pretty Photo CSS -->
        <link href="assets/css/prettyPhoto.css" rel="stylesheet">
		<!-- Custom Main StyleSheet CSS -->
        <link href="assets/css/component.css" rel="stylesheet">
		<!-- Pretty Photo CSS -->
        <link href="assets/css/jquery.bxslider.css" rel="stylesheet">
		<!-- Pretty Photo CSS -->
        <link href="assets/css/style5.css" rel="stylesheet">
		<!-- Pretty Photo CSS -->
        <link href="assets/css/demo.css" rel="stylesheet">
		<!-- Pretty Photo CSS -->
        <link href="assets/css/fig-hover.css" rel="stylesheet">
        <!-- Typography CSS -->
        <link href="assets/css/typography.css" rel="stylesheet">
        <!-- Custom Main StyleSheet CSS -->
        <link href="assets/style.css" rel="stylesheet">
		<!-- Custom Main StyleSheet CSS -->
        <link href="assets/css/component.css" rel="stylesheet">
		<!-- Custom Main StyleSheet CSS -->
        <link href="assets/css/shotcode.css" rel="stylesheet">
		<!-- Custom Main StyleSheet CSS -->
        <link href="assets/svg-icon.css" rel="stylesheet">
        <!-- Color CSS -->
        <link href="assets/css/color.css" rel="stylesheet">
        <!-- Responsive CSS -->
        <link href="assets/css/responsive.css" rel="stylesheet">
		<!-- ICONS CSS -->
        <link href="assets/css/sidebar-widget.css" rel="stylesheet">
    </head>
    <body class="demo-5">
        <!--WRAPPER START--> 
        <div class="wrapper"> 
			<header>
				<!--CITY TOP WRAP START--> 
				<div class="city_top_wrap">
					<div class="container-fluid">
						<div class="city_top_logo">
							<figure>
								<h1><a href="#"><img src="assets/images/top-logo.png" alt=""></a></h1>
							</figure>
						</div>
						<div class="city_top_news">
							<H5><b>MINISTERE DE L'ENERGIE, DU PETROLE ET DES MINES</b></H5>
							
						</div>
						<div class="city_top_social">
							<ul>
								<li><a href="https://www.facebook.com/MPESenegal/" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://x.com/MpeSenegal" target="_blank"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/company/minist%C3%A8re-du-p%C3%A9trole-et-des-energies-mpe-s%C3%A9n%C3%A9gal/?originalSubdomain=sn" target="_blank"><i class="fa fa-linkedin"></i></a></li>
								<!-- <li><a href="https://x.com/MpeSenegal" target="_blank"><i class="fa fa-youtube"></i></a></li> -->
								<!-- <li><a href="https://x.com/MpeSenegal" target="_blank"><i class="fa fa-google"></i></a></li> -->
							</ul>
						</div>
						
					</div>
				</div>
				<!--CITY TOP WRAP END-->
				
				<!--CITY TOP NAVIGATION START-->
				<div class="city_top_navigation">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-9">
								<div class="navigation">
									<ul>
										<li><a href="accueil">ACCUEIL</a></li>
										
										<li><a href="#">LE MINISTERE</a>
											<ul class="child">
												<li><a href="cabinet">CABINET</a></li>
												<li><a href="sg">SECRETARIAT GENERAL</a></li>
												<li><a href="directions">DIRECTIONS</a>
												</li>
												<li><a href="organismes">ORGANISMES</a>
												</li>
											</ul>
										</li>
										<li><a href="#">SECTEURS</a>
											<ul class="child">
												<li><a href="energie">ENERGIE</a>
													<ul class="child">
														<li><a href="electricite">Electricite</a></li>
														<li><a href="renouvelable">Energies renouvelables</a></li>
													</ul>
												</li>
												<li><a href="petrole">PETROLE</a>
													<ul class="child">
														<li><a href="petrole">Petrole</a></li>
														<li><a href="gaz">Gaz</a></li>
														<li><a href="hydrocarbure">Hydrocarbures</a></li>
												    </ul>
												</li>
												<li><a href="mines">MINES</a>
													<ul class="child">
														<li><a href="mines">MINES</a></li>
														<li><a href="geologie">GEOLOGIE</a></li>
												    </ul>
												</li>
											</ul>
										</li>
										<li><a href="#">SERVICES</a>
											<ul class="child">
												<li><a href="licence">LICENCE DE DISTRIBUTION</a></li>
												<li><a href="titre">TITRE MINIER</a></li>
												<li><a href="permis">PERMIS DE RECHERCHE</a></li>
												<li><a href="autorisations">AUTORISATION D'EXPLOITATION</a></li>
											</ul>
										</li>
										<li><a href="#">PUBLICATIONS</a>
											<ul class="child">
												<li><a href="conventions">CONVENTIONS MINIERES</a></li>
												<li><a href="lois_decrets_arretes">LOIS, DECRET ET ARRETES</a></li>
												<li><a href="contrats">CONTRATS</a></li>
												<li><a href="appel_offre">APPEL D'OFFRE</a></li>
											</ul>
										</li>
										<li><a href="actualites">ACTUALITES</a>
										</li>
										<li><a href="contact">CONTACTS</a></li>
									</ul>									
								</div>
								<!--DL Menu Start-->
								<div id="kode-responsive-navigation" class="dl-menuwrapper">
									<button class="dl-trigger">Menu</button>
									<ul class="dl-menu">
										<li><a class="active" href="accueil">ACCUEIL</a></li>
										<li class="menu-item kode-parent-menu"><a href="#">LE MINISTERE</a>
											<ul class="dl-submenu">
												<li><a href="cabinet">CABINET</a></li>
												<li><a href="sg">SECRETARIAT GENERAL</a></li>
												<li><a href="directions">DIRECTIONS</a>
												</li>
												<li><a href="organismes">ORGANISMES</a>
												</li>
											</ul>
										</li>
										<li class="menu-item kode-parent-menu"><a href="#">SECTEURS</a>
											<ul class="dl-submenu">
												<li><a href="energie">ENERGIE</a>
													<ul class="child">
														<li><a href="electricite">Electricite</a></li>
														<li><a href="renouvelable">Energies renouvelables</a></li>
													</ul>
												</li>
												<li><a href="petrole">PETROLE</a>
													<ul class="child">
														<li><a href="petrole">Petrole</a></li>
														<li><a href="gaz">Gaz</a></li>
														<li><a href="hydrocarbure">Hydrocarbures</a></li>
												    </ul>
												</li>
												<li><a href="mines">MINES</a>
													<ul class="child">
														<li><a href="mines">MINES</a></li>
														<li><a href="geologie">GEOLOGIE</a></li>
												    </ul>
												</li>
										</ul>
										</li>
										<li class="menu-item kode-parent-menu"><a href="#">SERVICES</a>
											<ul class="dl-submenu">
												<li><a href="licence">LICENCE DE DISTRIBUTION</a></li>
												<li><a href="titre">TITRE MINIER</a></li>
												<li><a href="permis">PERMIS DE RECHERCHE</a></li>
												<li><a href="autorisations">AUTORISATION D'EXPLOITATION</a></li>
											</ul>
										</li>
										<li class="menu-item kode-parent-menu"><a href="#">PUBLICATIONS</a>
											<ul class="dl-submenu">
												<li><a href="conventions">CONVENTIONS MINIERES</a></li>
												<li><a href="lois_decrets_arretes">LOIS, DECRET ET ARRETES</a></li>
												<li><a href="contrat">CONTRATS</a></li>
												<li><a href="appel">APPEL D'OFFRE</a></li>
											</ul>
										</li>
										<li><a href="actualites">ACTUALITES</a></li>
										<li><a href="contact">CONTACTS</a></li>
									</ul>
								</div>
								<!--DL Menu END-->
							</div>
							<div class="col-md-3">
								<div class="city_top_form">
									<div class="city_top_search">
										<input type="text" placeholder="Recherche">
										<a href="#"><i class="fa fa-search"></i></a>
									</div>
									<a class="top_user" href="login.html"><i class="fa fa-user"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>	
				<!--CITY TOP NAVIGATION END-->
				
				<!--CITY TOP NAVIGATION START-->
				<div class="city_top_navigation hide">
					<div class="container-fluid">
						<div class="city_top_logo">
							<figure>
								<h1><a href="#"><img src="assets/images/top-logo.png" alt="kodeforest"></a></h1>
							</figure>
						</div>
						<div class="city_top_news">
							<span>City News</span>
							<div class="city-news-slider">
								<div>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry <i class="fa fa-star"></i></p>
								</div>
								<div>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry <i class="fa fa-star"></i></p>
								</div>
								<div>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry <i class="fa fa-star"></i></p>
								</div>
							</div>
						</div>
						<div class="city_top_social">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube"></i></a></li>
								<li><a href="#"><i class="fa fa-google"></i></a></li>
							</ul>
						</div>
						
					</div>
				</div>	
				<!--CITY TOP NAVIGATION END-->
			</header>