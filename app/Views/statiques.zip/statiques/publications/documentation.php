			<!-- SAB BANNER START-->
			<!-- <div class="sab_banner overlay">
				<div class="container">
					<div class="sab_banner_text">
						<h2>News Post</h2>
						<ul class="breadcrumb">
						  <li class="breadcrumb-item"><a href="#">Home</a></li>
						  <li class="breadcrumb-item active">News Post</li>
						</ul>
					</div>
				</div>
			</div> -->
			<!-- SAB BANNER END-->
			
			<!-- CITY EVENT2 WRAP START-->
			<div class="city_blog2_wrap">
				<div class="container">
					
					<div class="col-md-12">
							<div class="city_health2_row">

								<!--CITY HEALTH TEXT START-->
								<div class="city_health2_text text2">
									<!--SECTION HEADING START-->
									<div class="section_heading">
										<span>Welcome to Local City</span>
										<h3>DOCUMENTATION</h3>
									</div>
									<!--SECTION HEADING END-->
									<p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat just</p>
								</div>
								<!--CITY HEALTH TEXT END-->
								
							</div>
						</div>
					<div class="row">
						<div class="col-md-6">
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
									
							</div>

							
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post4.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
									
							</div>
							
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post5.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
							</div>
							
						</div>
						<div class="col-md-6">
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
									
							</div>
							
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post1.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
									
							</div>
							
							<div class="city_news2_post post2">
								<figure class="box">
									<div class="box-layer layer-1"></div>
									<div class="box-layer layer-2"></div>
									<div class="box-layer layer-3"></div>
									<img src="assets/extra-images/news-post2.jpg" alt="">
								</figure>
								<div class="city_news2_detail">
									<ul class="city_meta_list">
										<li><a href="#"><i class="fa fa-calendar"></i>21.03.2018</a></li>
									</ul>
									<h4>Proin grida nibh vel velit auctor</h4>
									<a class="theam_btn bg-color color" href="#" tabindex="0">Read More</a>
								</div>
									
							</div>
							
						
							
					
							
						</div>
						<div class="col-md-12">
							<div class="pagination">
								<ul>
									<li><a href="#"><i class="fa fa-angle-left"></i></a></li>
									<li><a href="#">01</a></li>
									<li><a href="#">02</a></li>
									<li><a href="#">....</a></li>
									<li><a href="#">08</a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i></a></li>
								</ul>
							</div>
						</div>
					</div>	
				</div>
			</div>
			<!-- CITY EVENT2 WRAP END-->